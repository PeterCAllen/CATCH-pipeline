#!/usr/bin/env Rscript
# ============================================================================
# Generate TSV files from mBAT-combo results for scDRS, for ALL single-cell
# datasets. Each dataset gets TSV filtered by that dataset's expressed gene
# list. Based on scDRS.Rmd mBAT section (P_mBATcombo -> Z, top genes).
# ============================================================================
# Usage: Rscript generate_TSV_mBAT_all_datasets.R
# Before running: set paths in CONFIGURATION and ensure mBAT and gene lists exist.
# ============================================================================

library(data.table)
library(dplyr)

# ============================================
# CONFIGURATION - MODIFY THESE
# ============================================

# Directory containing mBAT .gene.assoc.mbat files (one per trait)
# Files expected: {trait}.gene.assoc.mbat
MBAT_DIR <- "/QRISdata/Q9052/bmrc_transfer/mBAT_benchmark"
# Or: "/well/visscher-wray/shared/tmp_Ang/benchmark_mBAT_missed"

# Base output directory for TSV files (one dir per method: mBAT_benchmark)
TSV_BASE_DIR <- "/QRISdata/Q9052/Prep_of_scDRS/tsv/mBAT_1kg_eur_benchmark"

# Directory containing per-dataset gene lists from 0.extract_gene_list.R
# Files expected: {dataset_name}_gene_list.csv
GENE_LIST_DIR <- "/QRISdata/Q9052/scData/preprocess_gene_lists"
# BMRC: "/well/visscher-wray/shared/tmp_Ang/scData/preprocess_gene_lists"

FILE_SUFFIX <- "_10kb"
N_MAX <- 1000L  # max genes per trait (top by P_mBATcombo)

# P to Z (two-tailed)
p_to_z <- function(p) {
  p <- pmax(p, .Machine$double.xmin)
  qnorm(p / 2, lower.tail = FALSE)
}

# List of dataset names (must match gene list file names)
DATASETS <- c(
  "2019_Smillie_normal_min20_pc",
  "2019_Smillie_normal_min20",
  "CARE_snRNA_Heart_pc",
  "CARE_snRNA_Heart",
  "Cheng_2018_Cell_Reports_pc",
  "Cheng_2018_Cell_Reports_updated",
  "Fasolino_2022_Nat_Metab_normal_only_pc",
  "Fasolino_2022_Nat_Metab_normal_only",
  "FBM_Jardine_2021_Nature_pc",
  "FBM_Jardine_2021_Nature",
  "HLCA_core_healthy_LP_pc",
  "HLCA_core_healthy_LP",
  "human_liver_atlas_Guilliams_2022_cell_pc",
  "human_liver_atlas_Guilliams_2022_cell",
  "Kamath_2022_normal_pc",
  "Kamath_2022_normal",
  "TabulaSapiens_pc_1to1_TMS_min20",
  "TabulaSapiens_pc_minCell20",
  "TMS_pc_1to1_TS_min20"
)

# ============================================

dir.create(TSV_BASE_DIR, showWarnings = FALSE, recursive = TRUE)
if (!dir.exists(MBAT_DIR)) stop("mBAT directory not found: ", MBAT_DIR)
if (!dir.exists(GENE_LIST_DIR)) stop("Gene list directory not found: ", GENE_LIST_DIR)

# Discover mBAT trait files (e.g. Trait.gene.assoc.mbat -> Trait)
mbat_files <- list.files(MBAT_DIR, pattern = "\\.gene\\.assoc\\.mbat$", full.names = FALSE)
if (length(mbat_files) == 0) stop("No *.gene.assoc.mbat files in: ", MBAT_DIR)
get_trait <- function(f) gsub("\\.gene\\.assoc\\.mbat$", "", f)
traits <- vapply(mbat_files, get_trait, character(1))

cat("============================================\n")
cat("Generate TSV from mBAT-combo for all datasets\n")
cat("============================================\n")
cat("mBAT dir:", MBAT_DIR, "\n")
cat("TSV base dir:", TSV_BASE_DIR, "\n")
cat("Gene list dir:", GENE_LIST_DIR, "\n")
cat("Datasets:", length(DATASETS), "\n")
cat("Traits:", length(traits), "\n")
cat("N_MAX:", N_MAX, "\n")
cat("============================================\n\n")

for (ds in DATASETS) {
  gene_list_csv <- file.path(GENE_LIST_DIR, paste0(ds, "_gene_list.csv"))
  if (!file.exists(gene_list_csv)) {
    warning("Gene list not found for ", ds, ": ", gene_list_csv, " - skipping dataset")
    next
  }
  gene_exp <- fread(gene_list_csv, header = TRUE)
  if (!"Gene" %in% names(gene_exp)) {
    if ("gene" %in% names(gene_exp)) names(gene_exp)[names(gene_exp) == "gene"] <- "Gene"
    else stop("Gene list must have column 'Gene' or 'gene': ", gene_list_csv)
  }
  gene_exp <- unique(gene_exp$Gene)

  for (j in seq_along(mbat_files)) {
    f <- mbat_files[j]
    trait <- traits[j]
    mbat_file <- file.path(MBAT_DIR, f)
    res <- tryCatch({
      res <- fread(mbat_file, header = TRUE)
      res <- inner_join(res, data.frame(Gene = gene_exp), by = "Gene")
      if (!"P_mBATcombo" %in% names(res)) stop("P_mBATcombo not in ", mbat_file)
      res <- res %>%
        mutate_at("P_mBATcombo", ~ replace(., . == 0, min(as.numeric(.[. > 0]), na.rm = TRUE)))
      res <- res %>% arrange(P_mBATcombo) %>% mutate(Z = p_to_z(P_mBATcombo))
      # Column name "zscore" required for scdrs munge-gs --weight zscore
      res <- res %>% dplyr::rename(GENE = Gene) %>% dplyr::select(GENE, Z)
      if (nrow(res) > N_MAX) res <- res[1:N_MAX, ]
      names(res)[2] <- "zscore"
      res
    }, error = function(e) {
      warning("Failed ", ds, " ", trait, ": ", conditionMessage(e))
      return(NULL)
    })
    if (is.null(res)) next
    out_file <- file.path(TSV_BASE_DIR, paste0(ds, "_", trait, FILE_SUFFIX, ".tsv"))
    data.table::fwrite(res, out_file, sep = "\t", quote = FALSE)
    cat("  ", ds, " ", trait, " -> ", nrow(res), " genes\n", sep = "")
  }
  cat("Done dataset:", ds, "\n")
}

cat("\n============================================\n")
cat("mBAT TSV generation finished.\n")
cat("============================================\n")
