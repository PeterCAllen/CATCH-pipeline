library(zellkonverter)
library(SingleCellExperiment)
library(tools)

# -------- paths --------
input_dir  <- "/QRISdata/Q9052/scData/preprocess"
output_dir <- "/QRISdata/Q9052/scData/preprocess_gene_lists"

dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

# -------- list all h5ad files --------
h5ad_files <- list.files(
  path = input_dir,
  pattern = "\\.h5ad$",
  full.names = TRUE
)

cat("Found", length(h5ad_files), "h5ad files\n")

# -------- loop over datasets --------
for (f in h5ad_files) {
  dataset_name <- file_path_sans_ext(basename(f))
  cat("Processing:", dataset_name, "\n")
  
  # read h5ad
  sce <- readH5AD(f)
  
  # extract gene list
  gene_list <- rownames(sce)
  
  # save
  out_file <- file.path(
    output_dir,
    paste0(dataset_name, "_gene_list.csv")
  )
  
  write.csv(
    data.frame(Gene = gene_list),
    out_file,
    row.names = FALSE,
    quote = FALSE
  )
}
