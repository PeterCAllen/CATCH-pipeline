#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=15
#SBATCH --mem=120G
#SBATCH --time=24:00:00
#SBATCH --job-name=scDRS_mBAT
#SBATCH --partition=general
#SBATCH --account=a_imb_cpdg
#SBATCH --array=1-56

# Logs: set SLURM_LOGDIR before sbatch or edit the two lines below to your path
#SBATCH --error=slurm_mBAT_%A_%a.error
#SBATCH --output=slurm_mBAT_%A_%a.out

# ============================================================================
# scDRS worker (Bunya, mBAT gene sets): one (dataset × 56 traits) per pipeline.
# Set PIPELINE (A|B|C) and DATASET_NAME via sbatch --export=.
#   A = Baseline:           scRNA_pc + GWAS_PC_top1000  -> results/A_baseline/
#   B = scRNA expr universe: scRNA_expr + GWAS_PC_top1000 -> results/B_expr_universe/
#   C = GWAS expr universe:  scRNA_pc + GWAS_EXPR_top1000 -> results/C_gwas_universe/
# ============================================================================
# Usage: sbatch --export=PIPELINE=A,DATASET_NAME=CARE_snRNA_Heart_pc scripts/scdrs_worker_mBAT.sh
# ============================================================================
# Bunya: conda activate scdrs_scanpy
# Gene sets: /QRISdata/Q9052/benchmark/mBAT_1kg_eur_benchmark
# scData:    /QRISdata/Q9052/scData/preprocess
# ============================================================================

set -e

# Conda on Bunya

source "$(conda info --base)/etc/profile.d/conda.sh"
CONDA_ENV_PATH="${CONDA_ENV_PATH:-/scratch/user/uqali4/micromamba/envs/scRNA_env}"
conda activate "${CONDA_ENV_PATH}"


i=${SLURM_ARRAY_TASK_ID}
TASKFILE="${TASKFILE:-/QRISdata/Q9052/benchmark/benchmark_traits.txt}"
trait=$(sed -n "${i}p" "$TASKFILE" | xargs)

PIPELINE="${PIPELINE:-A}"
DATASET_NAME="${DATASET_NAME:-}"

BASE_SCDATA="/QRISdata/Q9052/scData/preprocess"
BASE_RESULTS="${BASE_RESULTS:-/QRISdata/Q9052/scDRS_res}"
BASE_GS="/QRISdata/Q9052/benchmark/mBAT_1kg_eur_benchmark"

# .gs naming: {h5ad_prefix}_{trait}_10kb.gs (trait = line from benchmark_traits.txt)
GS_DIR="${BASE_GS}"
FILE_SUFFIX="_10kb"
DATASET_PREFIX="${DATASET_NAME}_"

if [ -z "${DATASET_NAME}" ]; then
  echo "ERROR: Set DATASET_NAME (e.g. sbatch --export=PIPELINE=A,DATASET_NAME=CARE_snRNA_Heart_pc ...)"
  exit 1
fi

case "${PIPELINE}" in
  A)
    gs_dir="${GS_DIR}"
    score_folder="${BASE_RESULTS}/A_baseline_step1_mBAT/${DATASET_NAME}"
    downstream_folder="${BASE_RESULTS}/A_baseline_step2_mBAT/${DATASET_NAME}"
    ;;
  B)
    gs_dir="${GS_DIR}"
    score_folder="${BASE_RESULTS}/B_expr_universe_step1_mBAT/${DATASET_NAME}"
    downstream_folder="${BASE_RESULTS}/B_expr_universe_step2_mBAT/${DATASET_NAME}"
    ;;
  C)
    gs_dir="${GS_DIR}"
    score_folder="${BASE_RESULTS}/C_gwas_universe_step1_mBAT/${DATASET_NAME}"
    downstream_folder="${BASE_RESULTS}/C_gwas_universe_step2_mBAT/${DATASET_NAME}"
    ;;
  *)
    echo "ERROR: PIPELINE must be A, B, or C (got ${PIPELINE})"
    exit 1
    ;;
esac

h5ad_file="${BASE_SCDATA}/${DATASET_NAME}.h5ad"
cov_file="${BASE_SCDATA}/${DATASET_NAME}.cov"
gs_file="${gs_dir}/${DATASET_PREFIX}${trait}${FILE_SUFFIX}.gs"

# Per-dataset: group column and raw count flag
case "${DATASET_NAME}" in
  2019_Smillie_normal_min20|2019_Smillie_normal_min20_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="False" ;;
  CARE_snRNA_Heart|CARE_snRNA_Heart_pc)
    GROUP_ANALYSIS="celltype"; FLAG_RAW_COUNT="False" ;;
  Cheng_2018_Cell_Reports_updated|Cheng_2018_Cell_Reports_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="False" ;;
  Fasolino_2022_Nat_Metab_normal_only|Fasolino_2022_Nat_Metab_normal_only_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="False" ;;
  FBM_Jardine_2021_Nature|FBM_Jardine_2021_Nature_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="False" ;;
  HLCA_core_healthy_LP|HLCA_core_healthy_LP_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="True" ;;
  human_liver_atlas_Guilliams_2022_cell|human_liver_atlas_Guilliams_2022_cell_pc)
    GROUP_ANALYSIS="cell_type"; FLAG_RAW_COUNT="False" ;;
  Kamath_2022_normal|Kamath_2022_normal_pc)
    GROUP_ANALYSIS="Cell_type_refined"; FLAG_RAW_COUNT="True" ;;
  TabulaSapiens_pc_minCell20|TabulaSapiens_pc_1to1_TMS_min20)
    GROUP_ANALYSIS="cell_ontology_class"; FLAG_RAW_COUNT="True" ;;
  TMS_pc_1to1_TS_min20)
    GROUP_ANALYSIS="cell_ontology_class"; FLAG_RAW_COUNT="True" ;;
  *)
    echo "ERROR: Unknown DATASET_NAME=${DATASET_NAME}"
    exit 1
    ;;
esac

mkdir -p "${score_folder}" "${downstream_folder}"

echo "============================================"
echo "mBAT | PIPELINE=${PIPELINE} | DATASET=${DATASET_NAME} | trait=${trait} (${i})"
echo "============================================"

if [ ! -f "${gs_file}" ]; then
  echo "ERROR: Gene set not found: ${gs_file}"
  exit 1
fi
if [ ! -f "${h5ad_file}" ]; then
  echo "ERROR: H5AD not found: ${h5ad_file}"
  exit 1
fi
if [ ! -f "${cov_file}" ]; then
  echo "ERROR: COV not found: ${cov_file}"
  exit 1
fi

OUT_TEMP="${score_folder}/.tmp_${i}"
mkdir -p "${OUT_TEMP}"
rm -f "${OUT_TEMP}"/*.gz 2>/dev/null || true

scdrs compute-score \
  --h5ad-file "${h5ad_file}" \
  --h5ad-species human \
  --gs-file "${gs_file}" \
  --gs-species human \
  --out-folder "${OUT_TEMP}" \
  --cov-file "${cov_file}" \
  --flag-filter-data True \
  --flag-raw-count "${FLAG_RAW_COUNT}" \
  --n-ctrl 1000 \
  --flag-return-ctrl-raw-score False \
  --flag-return-ctrl-norm-score True

if [ $? -ne 0 ]; then
  echo "ERROR: compute-score failed"
  rm -rf "${OUT_TEMP}"
  exit 1
fi

final_full="${score_folder}/${trait}${FILE_SUFFIX}.full_score.gz"
final_score="${score_folder}/${trait}${FILE_SUFFIX}.score.gz"
scored=$(find "${OUT_TEMP}" -maxdepth 1 -name "*.full_score.gz" | head -n 1)
[ -n "${scored}" ] && mv "${scored}" "${final_full}"
scored2=$(find "${OUT_TEMP}" -maxdepth 1 -name "*.score.gz" | head -n 1)
[ -n "${scored2}" ] && mv "${scored2}" "${final_score}"
rm -rf "${OUT_TEMP}"

if [ ! -f "${final_full}" ]; then
  echo "ERROR: No .full_score.gz produced in temp dir for trait ${trait}"
  exit 1
fi
score_file="${final_full}"

scdrs perform-downstream \
  --h5ad-file "${h5ad_file}" \
  --score-file "${score_file}" \
  --out-folder "${downstream_folder}" \
  --group-analysis "${GROUP_ANALYSIS}" \
  --gene-analysis \
  --flag-filter-data True \
  --flag-raw-count "${FLAG_RAW_COUNT}"

echo "Done: mBAT | PIPELINE=${PIPELINE} | ${trait} | ${DATASET_NAME}"
