#Resource: https://cellxgene.cziscience.com/collections/51544e44-293b-4c2b-8c26-560678423380
#wget https://datasets.cellxgene.cziscience.com/111d6e7d-d3d2-48fd-907a-4d3f8c77ee93.h5ad
#This download link permanently references this version of the dataset. 
# If this dataset is updated, a new download link will be created that permanently references the next version of this dataset.

#https://www.nature.com/articles/s42255-022-00531-x
#Fasolino et al. (2022) Nat Metab


import scanpy as sc
import pandas as pd
import numpy as np

sce = sc.read_h5ad("/QRISdata/Q9052/scData/raw/111d6e7d-d3d2-48fd-907a-4d3f8c77ee93.h5ad")
#count_matrix = sce.to_df(), count_matrix,it is a normlized data
sce_normal = sce[sce.obs['disease'] == 'normal'].copy()


# Replace hyphens and commas with underscores
sce_normal.obs['cell_type'] = sce_normal.obs['cell_type'].str.replace(' ', '_')
sce_normal.obs.cell_type = sce_normal.obs.cell_type.str.replace("-", "_")
sce_normal.obs.cell_type = sce_normal.obs.cell_type.str.replace(",", "_")
sce_normal.obs['cell_type']

# Remove cell types with number of cells<20
CT_counts = sce_normal.obs['cell_type'].value_counts()
print(CT_counts) # all cell types have >20 cells

sce_normal.write("/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only.h5ad")

# Generate PC gene version
file_path = "/QRISdata/Q9052/gene_coordinate/geneMatrix.56778genes.tsv"
gene_coordinates = pd.read_csv(file_path, delimiter='\t') 

# Filter gene_coordinates to get only 'protein_coding' genes
protein_coding_genes = gene_coordinates[gene_coordinates['gene_type'] == 'protein_coding'] #18993

# Filter the AnnData object to keep only genes found in protein_coding_genes: 18157
subset_pc = sce_normal[:, sce_normal.var.index.isin(protein_coding_genes['Gene'])]

subset_pc.write_h5ad('/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only_pc.h5ad')

# Generate cov for scDRS analysis later
# Make .cov file 
df_cov = pd.DataFrame(index=sce_normal.obs.index)
df_cov['const'] = 1
df_cov['n_genes'] = (sce_normal.X>0).sum(axis=1)
for donor in sorted(set(sce_normal.obs['donor_id'])):
    if donor!='HPAP022':
        df_cov['donor_id%s'%donor] = (sce_normal.
                                      obs['donor_id']==donor)*1    
        
df_cov.to_csv('/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only.cov', sep='\t')


# Make .cov file 
df_pc_cov = pd.DataFrame(index=subset_pc.obs.index)
df_pc_cov['const'] = 1
df_pc_cov['n_genes'] = (subset_pc.X>0).sum(axis=1)
for donor in sorted(set(subset_pc.obs['donor_id'])):
    if donor!='H02':
        df_pc_cov['donor_id%s'%donor] = (subset_pc.obs['donor_id']==donor)*1    
df_pc_cov.to_csv('/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only_pc.cov', sep='\t')

# Count cell types save
CT_counts.to_csv('/QRISdata/Q9052/scData/cell_type_list/Fasolino_2022_Nat_Metab_normal_only.cell_type_counts.txt', sep='\t', header=True)
