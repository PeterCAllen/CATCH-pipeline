# General script to process all single-cell datasets and convert to Cepo format
# Handles both normalized and raw_counts data (no need to check - already known)
.libPaths(c("~/R/library", .libPaths()))

library(data.table)
library(dplyr)
library(tidyr)
library(tidyverse)
library(stringr)
library(Cepo)
library(SingleCellExperiment)
library(zellkonverter)
library(DelayedMatrixStats)
library(DelayedArray)
library(scater)

# ============================================
# Function to process a single dataset with Cepo
# ============================================
process_dataset_to_Cepo <- function(
    h5ad_file,                    # Path to .h5ad file
    output_dir,                  # Output directory for Cepo CSV files
    is_normalized = TRUE,         # TRUE if data is normalized, FALSE if raw_counts
    cell_type_label = "cell_type", # Column name for cell type annotation in colData
    prefix = NULL                 # Prefix for output file name
) {
  
  cat("\n========================================\n")
  cat("Processing:", basename(h5ad_file), "\n")
  cat("Normalized:", is_normalized, "\n")
  cat("Cell type label:", cell_type_label, "\n")
  cat("========================================\n")
  
  # Step 1: Load h5ad file
  cat("Loading h5ad file...\n")
  sce <- readH5AD(h5ad_file)
  
  # Step 2: Get expression data
  assay(sce, "counts") <- assay(sce)
  exp <- counts(sce)
  dexp <- as.matrix(exp)
  
  # Step 3: Prepare data for Cepo
  if (!is_normalized) {
    # For raw_counts: normalize with logNormCounts
    cat("Normalizing raw counts with logNormCounts...\n")
    sce2 <- SingleCellExperiment(list(counts = dexp))
    colData(sce2) <- colData(sce)
    rowData(sce2) <- rowData(sce)
    sce2 <- scater::logNormCounts(sce2)
    # Use normalized counts for Cepo
    exp_for_cepo <- logcounts(sce2)
  } else {
    # For normalized data: use as-is (don't normalize again)
    cat("Data is already normalized, using directly...\n")
    exp_for_cepo <- dexp
  }
  
  # Step 4: Get cell type labels
  if (!cell_type_label %in% colnames(colData(sce))) {
    stop("Cell type label '", cell_type_label, "' not found in colData. Available columns: ", 
         paste(colnames(colData(sce)), collapse = ", "))
  }
  
  cell_types <- colData(sce)[[cell_type_label]]
  cat("Found", length(unique(cell_types)), "unique cell types.\n")
  
  # Step 5: Run Cepo
  cat("Running Cepo...\n")
  # Cepo function: Cepo(exprsMat, cellType, ...)
  # Note: reference code uses cellType (singular), not cellTypes
  cepo_result <- Cepo(exprsMat = exp_for_cepo, cellType = cell_types)
  
  # Step 6: Extract stats from Cepo result
  cat("Extracting Cepo stats...\n")
  # Cepo returns an object with $stats component (not the full result)
  cepo_df <- as.data.frame(cepo_result$stats)
  
  # Add gene names as column
  cepo_df$gene <- rownames(cepo_df)
  
  # Move gene column to first position and ensure it's named "gene"
  cepo_df <- cepo_df %>% relocate(gene)
  
  # Ensure first column is named "gene"
  names(cepo_df)[1] <- "gene"
  
  # Remove rownames
  rownames(cepo_df) <- NULL
  
  # Clean cell type names (replace spaces, commas, dots, and slashes with underscores)
  names(cepo_df) <- names(cepo_df) %>%
    str_replace_all(" ", "_") %>%
    str_replace_all(",", "_") %>%
    str_replace_all("\\.", "_") %>%
    str_replace_all("/", "_")
  
  # Check for NA values
  na_indices <- which(is.na(cepo_df), arr.ind = TRUE)
  if (nrow(na_indices) > 0) {
    cat("Warning: NA values found at", nrow(na_indices), "positions.\n")
    na_rows <- unique(na_indices[,1])
    cat("Rows with NA values:", length(na_rows), "\n")
  } else {
    cat("No NA values found in the data frame.\n")
  }
  
  # Step 7: Save output as compressed CSV
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  output_file <- paste0(output_dir, "/", prefix, ".cepo.csv.gz")
  write.table(cepo_df, gzfile(output_file), 
              row.names = FALSE, col.names = TRUE, quote = FALSE, sep = ",")
  
  cat("Saved Cepo file to:", output_file, "\n")
  cat("Dimensions:", dim(cepo_df), "\n")
  cat("Completed processing:", prefix, "\n\n")
  
  return(cepo_df)
}

# ============================================
# Dataset configuration
# ============================================
# Define all datasets with their properties (same as TDEP script)
datasets <- list(
  list(path = "/QRISdata/Q9052/scData/preprocess/2019_Smillie_normal_min20.h5ad",
       label = "cell_type", prefix = "2019_Smillie_normal_min20", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/2019_Smillie_normal_min20_pc.h5ad",
       label = "cell_type", prefix = "2019_Smillie_normal_min20_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/CARE_snRNA_Heart.h5ad",
       label = "celltype", prefix = "CARE_snRNA_Heart", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/CARE_snRNA_Heart_pc.h5ad",
       label = "celltype", prefix = "CARE_snRNA_Heart_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Cheng_2018_Cell_Reports_updated.h5ad",
       label = "cell_type", prefix = "Cheng_2018_Cell_Reports_updated", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Cheng_2018_Cell_Reports_pc.h5ad",
       label = "cell_type", prefix = "Cheng_2018_Cell_Reports_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only.h5ad",
       label = "cell_type", prefix = "Fasolino_2022_Nat_Metab_normal_only", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Fasolino_2022_Nat_Metab_normal_only_pc.h5ad",
       label = "cell_type", prefix = "Fasolino_2022_Nat_Metab_normal_only_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/FBM_Jardine_2021_Nature.h5ad",
       label = "cell_type", prefix = "FBM_Jardine_2021_Nature", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/FBM_Jardine_2021_Nature_pc.h5ad",
       label = "cell_type", prefix = "FBM_Jardine_2021_Nature_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/HLCA_core_healthy_LP.h5ad",
       label = "cell_type", prefix = "HLCA_core_healthy_LP", is_normalized = FALSE),
  list(path = "/QRISdata/Q9052/scData/preprocess/HLCA_core_healthy_LP_pc.h5ad",
       label = "cell_type", prefix = "HLCA_core_healthy_LP_pc", is_normalized = FALSE),
  list(path = "/QRISdata/Q9052/scData/preprocess/human_liver_atlas_Guilliams_2022_cell.h5ad",
       label = "cell_type", prefix = "human_liver_atlas_Guilliams_2022_cell", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/human_liver_atlas_Guilliams_2022_cell_pc.h5ad",
       label = "cell_type", prefix = "human_liver_atlas_Guilliams_2022_cell_pc", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Kamath_2022_normal.h5ad",
       label = "Cell_type_refined", prefix = "Kamath_2022_normal", is_normalized = FALSE),
  list(path = "/QRISdata/Q9052/scData/preprocess/Kamath_2022_normal_pc.h5ad",
       label = "Cell_type_refined", prefix = "Kamath_2022_normal_pc", is_normalized = FALSE),
  list(path = "/QRISdata/Q9052/scData/preprocess/TabulaSapiens_pc_minCell20.h5ad",
       label = "cell_ontology_class", prefix = "TabulaSapiens_pc_minCell20", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/TabulaSapiens_pc_1to1_TMS_min20.h5ad",
       label = "cell_ontology_class", prefix = "TabulaSapiens_pc_1to1_TMS_min20", is_normalized = TRUE),
  list(path = "/QRISdata/Q9052/scData/preprocess/TMS_pc_1to1_TS_min20.h5ad",
       label = "cell_ontology_class", prefix = "TMS_pc_1to1_TS_min20", is_normalized = FALSE)
)

# ============================================
# Define output directory
# ============================================
output_dir <- "/QRISdata/Q9052/benchmark/Statistics"

# ============================================
# Process all datasets
# ============================================
results <- list()

for (i in seq_along(datasets)) {
  dataset <- datasets[[i]]
  
  tryCatch({
    result <- process_dataset_to_Cepo(
      h5ad_file = dataset$path,
      output_dir = output_dir,
      is_normalized = dataset$is_normalized,
      cell_type_label = dataset$label,
      prefix = dataset$prefix
    )
    results[[dataset$prefix]] <- result
  }, error = function(e) {
    cat("ERROR processing", dataset$prefix, ":", conditionMessage(e), "\n")
  })
}

cat("\n========================================\n")
cat("Processing complete!\n")
cat("Processed", length(results), "datasets successfully.\n")
cat("========================================\n")

